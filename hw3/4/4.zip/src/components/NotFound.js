const NotFound = () => {
    return '404 not found!'
};

export default NotFound;