module.exports = {
  secret: "chat-secret-key"
};
